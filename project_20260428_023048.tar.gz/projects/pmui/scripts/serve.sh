#!/bin/bash
# PMUI 原型预览服务器启动脚本
# 用法: bash serve.sh [端口号] [原型目录]

PORT=${1:-9000}
DIR=${2:-.}

echo "🚀 启动 PMUI 原型预览服务器"
echo "   地址: http://localhost:$PORT"
echo "   目录: $DIR"
echo "   按 Ctrl+C 停止"
echo ""

cd "$DIR" && python3 -m http.server $PORT
